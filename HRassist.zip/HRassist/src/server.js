import { initializeApp } from 'firebase/app'

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
export const firebaseConfig = {
  apiKey: "AIzaSyCDpeH-vfPrTJlMv_ryvSTF6NIOrMNmxc8",
  authDomain: "hrmis-14e94.firebaseapp.com",
  projectId: "hrmis-14e94",
  storageBucket: "hrmis-14e94.appspot.com",
  messagingSenderId: "293447221941",
  appId: "1:293447221941:web:e0472fc09c6452ffc574fc",
  measurementId: "G-JYWBBER86F"
};

/*
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
export const firebaseConfig = {
    apiKey: "AIzaSyAEQ1BCjp-kmG2YSPErSKCCky1uMUSBSMg",
    authDomain: "hrassist-lgusanvicente.firebaseapp.com",
    projectId: "hrassist-lgusanvicente",
    storageBucket: "hrassist-lgusanvicente.appspot.com",
    messagingSenderId: "525625289094",
    appId: "1:525625289094:web:8ca1d90be2dd275443e407",
    measurementId: "G-ZKCNETGSXG"
  };

*/